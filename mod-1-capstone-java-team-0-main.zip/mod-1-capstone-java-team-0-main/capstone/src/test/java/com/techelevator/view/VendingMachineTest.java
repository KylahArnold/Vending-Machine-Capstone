package com.techelevator.view;

import org.junit.Test;

public class VendingMachineTest {
    //Unable to make sufficient unit tests due to our methods being void or without parameters.
    //Future iterations can restructure methods to allow for testing.


//    @Test
//    public void ProvideValidSlot_ExpectPurchaseToSucceed(){
//        //Arrange
//        VendingMachine vendingMachine = new VendingMachine();
//
//        //Act
//        String slot = vendingMachine.selectAndPurchase("C3");
//
//        //Assert
//        assertEquals("Mountain Melter $1.50 Your remaining balance is $8.50 \n Glug, Glug, Yum!", slot)
//
//
//    }
}
